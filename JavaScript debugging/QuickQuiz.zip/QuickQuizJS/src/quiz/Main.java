
// ---------------------------------------------
// Project: QuickQuiz (Module 3)
// Student: Jessica Salazar
// Date: February 16, 2026
// Description: Entry point for the QuickQuiz Java console app.
// ---------------------------------------------
package quiz;

import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        QuizEngine engine = new QuizEngine();
        List<Question> questions = ((QuizEngine) engine).loadQuestions();

        // Use try-with-resources to close Scanner automatically
        try (Scanner scanner = new Scanner(System.in)) {
            boolean keepPlaying = true;

            while (keepPlaying) {
                ((QuizEngine) engine).runOnce(scanner, questions);
                keepPlaying = ((QuizEngine) engine).promptReplay(scanner);
            }

            System.out.println("Thanks for playing QuickQuiz!");
        } catch (Exception ex) {
            // Basic error handling (could be expanded with logging)
            System.err.println("An error occurred: " + ex.getMessage());
        }
    }
}
