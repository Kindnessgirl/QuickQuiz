
// ---------------------------------------------
// Project: QuickQuiz (Module 3)
// Student: Jessica Salazar
// Date: February 16, 2026
// Description: Core quiz logic: load questions, prompt user,
//              validate input, track score, and replay.
// ---------------------------------------------
package quiz;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class QuizEngine {

    /**
     * Builds an in-memory list of questions (KISS: no database).
     */
    public List<Question> loadQuestions() {
        List<Question> questions = new ArrayList<>();

        questions.add(new Question(
            "Which number is the smallest?",
            Arrays.asList("10", "3", "7", "5"),
            1 // "3"
        ));

        questions.add(new Question(
            "What does JS stand for?",
            Arrays.asList("JavaSyntax", "JavaScript", "JustScript", "JellyScript"),
            1
        ));

        questions.add(new Question(
            "Which value is a Boolean (true/false)?",
            Arrays.asList("42", "'true'", "true", "3.14"),
            2
        ));

        questions.add(new Question(
            "Array indexes in Java typically start at:",
            Arrays.asList("0", "1", "-1", "Any"),
            0
        ));

        questions.add(new Question(
            "Which is a loop structure?",
            Arrays.asList("IF/ELSE", "WHILE", "SWITCH", "TRY/CATCH"),
            1
        ));

        return questions;
    }

    /**
     * Runs one full quiz session and returns the user's score.
     * Handles input validation and shows feedback.
     */
    public int runOnce(Scanner scanner, List<Question> questions) {
        int score = 0;

        for (Question q : questions) {
            System.out.println("\n----------------------------------");
            System.out.println("Q: " + q.getText());

            List<String> choices = q.getChoices();
            for (int i = 0; i < choices.size(); i++) {
                System.out.printf("  %d. %s%n", i + 1, choices.get(i));
            }

            Integer selection = null;
            // Repeat until the user enters a valid option
            while (selection == null) {
                System.out.print("Select an option (1-" + choices.size() + "): ");
                String raw = scanner.nextLine().trim();
                try {
                    int n = Integer.parseInt(raw);
                    if (n >= 1 && n <= choices.size()) {
                        selection = n - 1; // convert to 0-based
                    } else {
                        System.out.println("Invalid input: enter a number between 1 and " + choices.size() + ".");
                    }
                } catch (NumberFormatException ex) {
                    System.out.println("Invalid input: please enter a number.");
                }
            }

            if (selection == q.getCorrectIndex()) {
                score++;
                System.out.println("✅ Correct!");
            } else {
                System.out.println("❌ Incorrect. Correct answer: " + choices.get(q.getCorrectIndex()));
            }
        }

        System.out.println("\n==================================");
        System.out.printf("Quiz complete! Your score: %d / %d%n", score, questions.size());
        System.out.println("==================================\n");

        return score;
    }

    /**
     * Ask the user if they want to replay the quiz.
     * Accepts: yes/y (case-insensitive) as affirmative; anything else as no.
     */
    public boolean promptReplay(Scanner scanner) {
        System.out.print("Play again? (yes/no): ");
        String ans = scanner.nextLine().trim().toLowerCase();
        return ans.equals("y") || ans.equals("yes");
    }
}
