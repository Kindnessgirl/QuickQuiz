
// ---------------------------------------------
// Project: QuickQuiz (Module 3)
// Student: Jessica Salazar
// Date: February 16, 2026
// Description: Data model representing a single quiz question.
// ---------------------------------------------
package quiz;

import java.util.List;

public class Question {
    private final String text;
    private final List<String> choices;
    private final int correctIndex;

    /**
     * Constructs a Question.
     * @param text The prompt shown to the user.
     * @param choices The possible answer choices (displayed 1..n).
     * @param correctIndex The 0-based index of the correct choice.
     */
    public Question(String text, List<String> choices, int correctIndex) {
        if (text == null || text.isBlank()) {
            throw new IllegalArgumentException("Question text cannot be null or blank.");
        }
        if (choices == null || choices.size() < 2) {
            throw new IllegalArgumentException("Question must have at least two choices.");
        }
        if (correctIndex < 0 || correctIndex >= choices.size()) {
            throw new IllegalArgumentException("correctIndex out of bounds.");
        }
        this.text = text;
        this.choices = List.copyOf(choices); // defensive copy
        this.correctIndex = correctIndex;
    }

    public String getText() {
        return text;
    }

    public List<String> getChoices() {
        return choices;
    }

    public int getCorrectIndex() {
        return correctIndex;
    }
}
