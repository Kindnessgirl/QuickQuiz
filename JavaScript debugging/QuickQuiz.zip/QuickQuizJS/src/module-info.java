/**
 * 
 */
/**
 * 
 */
module QuickQuiz {
}